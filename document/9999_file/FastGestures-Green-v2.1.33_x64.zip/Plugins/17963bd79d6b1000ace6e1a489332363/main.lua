if(arg[1]=='0') then
	fg_volume_switch()
end

if(arg[1]=='1') then
	fg_volume_dec()
end

if(arg[1]=='2') then
	fg_volume_inc()
end

if(arg[1]=='3') then
	fg_brightness_dec()
end


if(arg[1]=='4') then
	fg_brightness_inc()
end
